package com.assessment.services;

import com.assessment.utils.Employee;
import com.assessment.utils.EmployeeAlreadyExists;
import com.assessment.utils.TrainingAlreadyExists;

import java.time.LocalDate;

public interface RegistrationService {

    public void createEmployee(Employee employeeObj) throws EmployeeAlreadyExists;
    public void createTraining(int trainingId, String nameOfCourse, String[] skillsAcquiredByTraining, LocalDate startDate, LocalDate endDate) throws TrainingAlreadyExists;
    public void createTraining(int trainingId, String nameOfCourse, String[] skillsAcquiredByTraining, LocalDate startDate, LocalDate endDate, int labDuration);

    public void registerTraining(int trainingId, String employeeName);
}
