package com.assessment.services;

import com.assessment.utils.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class RegistrationImpl implements RegistrationService {
    Set<Employee> employeeList = new HashSet<>();
    List<Training> trainingList = new ArrayList<>();

    List<Registration> trainingRegisteredList = new ArrayList<>();

    public void createEmployee(Employee employeeObj) throws EmployeeAlreadyExists {
        try{
            if(employeeList.contains(employeeObj)){
                throw new EmployeeAlreadyExists("Employee already exists");
            }
            else{
                employeeList.add(employeeObj);
            }
        }
        catch (Exception e){
            System.out.println(e);
        }
    }

    public void createTraining(int trainingId, String nameOfCourse, String[] skillsAcquiredByTraining, LocalDate startDate, LocalDate endDate) throws TrainingAlreadyExists {
        try{
            Training obj = new Training(trainingId, nameOfCourse, skillsAcquiredByTraining, startDate, endDate);
            if(trainingList.contains(obj)){
                throw new TrainingAlreadyExists("Training already exists");
            }
            else{
                trainingList.add(obj);
            }
        }
        catch (Exception e){
            System.out.println(e);
        }

    }

    public void createTraining(int trainingId, String nameOfCourse, String[] skillsAcquiredByTraining, LocalDate startDate, LocalDate endDate, int labDuration){
        try{
            Training obj = new Training(trainingId, nameOfCourse, skillsAcquiredByTraining, startDate, endDate, labDuration);
            if(trainingList.contains(obj)){
                throw new TrainingAlreadyExists("Training already exists");
            }
            else{
                trainingList.add(obj);
            }
        }
        catch (Exception e){
            System.out.println(e);
        }
    }

    public void registerTraining(int trainingId, String employeeName){
        try{
            Registration obj = new Registration(trainingId, employeeName);
            if(trainingRegisteredList.contains(obj)){
                throw new TrainingIdNotAvailable("Training already registered");
            }
            else{
                trainingRegisteredList.add(obj);
            }
        }
        catch (Exception e){
            System.out.println(e);
        }
    }

}
