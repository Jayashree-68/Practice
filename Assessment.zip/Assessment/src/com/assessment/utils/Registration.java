package com.assessment.utils;

public class Registration {

    private int trainingId;

    private String employeeName;

    public Registration(int trainingId, String employeeName) {
        this.trainingId = trainingId;
        this.employeeName = employeeName;
    }
}
