package com.assessment.utils;

public class Employee {
    private int employeeId;
    private String employeeName;

    Employee(int employeeId, String employeeName){
        this.employeeId = employeeId;
        this.employeeName = employeeName;

    }

}
