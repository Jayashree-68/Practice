package com.assessment.utils;

public class TrainingIdNotAvailable extends Exception{

    private String message;

    public TrainingIdNotAvailable(String message) {
        super();
        this.message = message;
    }

    @Override
    public String getMessage() {
        return this.message;
    }
}
