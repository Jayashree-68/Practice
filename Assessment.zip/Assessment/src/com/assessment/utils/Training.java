package com.assessment.utils;

import java.time.LocalDate;

public class Training {
    private int trainingId;
    private String nameOfCourse;
    private String[] skillsAcquiredByTraining;
    private LocalDate startDate;
    private LocalDate endDate;
    private int labDuration;

    public Training(int trainingId, String nameOfCourse, String[] skillsAcquiredByTraining, LocalDate startDate, LocalDate endDate){
        this.trainingId = trainingId;
        this.nameOfCourse = nameOfCourse;
        this.skillsAcquiredByTraining = skillsAcquiredByTraining;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public Training(int trainingId, String nameOfCourse, String[] skillsAcquiredByTraining, LocalDate startDate, LocalDate endDate, int labDuration){
        this.trainingId = trainingId;
        this.nameOfCourse = nameOfCourse;
        this.skillsAcquiredByTraining = skillsAcquiredByTraining;
        this.startDate = startDate;
        this.endDate = endDate;
        this.labDuration = labDuration;
    }
}
