package com.assessment.utils;

import com.assessment.services.RegistrationService;


import java.time.LocalDate;

public class Application {
    Employee emp1 = new Employee(1400 ,"JayaShree");

    RegistrationService registrationService;


}
