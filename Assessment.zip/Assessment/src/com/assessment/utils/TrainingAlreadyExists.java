package com.assessment.utils;

public class TrainingAlreadyExists extends Exception {

    private String message;

    public TrainingAlreadyExists(String message) {
        super();
        this.message = message;
    }

    @Override
    public String getMessage() {
        return this.message;
    }
}
