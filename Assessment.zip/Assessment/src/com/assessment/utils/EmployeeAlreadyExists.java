package com.assessment.utils;

public class EmployeeAlreadyExists extends Exception {

    private String message;

    public EmployeeAlreadyExists(String message) {
        super();
        this.message = message;
    }

    @Override
    public String getMessage() {
        return this.message;
    }
}
